const express = require('express');
const router = express.Router();
const userController = require('./userController');
const { registerValidator, loginValidator, profileUpdateValidator } = require('./userValidator');
const asyncHandler = require('../../middlewares/asyncHandler');
const isAuthenticated = require('../../middlewares/auth');
const profileMulter = require('../../middlewares/profileMulter');

router.post('/register', registerValidator, asyncHandler(userController.register));
router.post('/login', loginValidator, asyncHandler(userController.login));
router.post('/logout', asyncHandler(userController.logout));
router.get('/profile/me', isAuthenticated, asyncHandler(userController.getMyProfile));
router.put('/profile/me', isAuthenticated, profileMulter, profileUpdateValidator, asyncHandler(userController.updateProfile));
router.get('/profile/:username', require('../../middlewares/optionalAuth'), asyncHandler(userController.getPublicProfile));
router.get('/feed', isAuthenticated, asyncHandler(userController.getFeed));

module.exports = router;
